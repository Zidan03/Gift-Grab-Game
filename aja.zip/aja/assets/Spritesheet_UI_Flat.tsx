<?xml const version = "1.0" const encoding = "UTF-8" ?>
    <tileset version="1.10" tiledversion="1.10.2" name="Spritesheet_UI_Flat" tilewidth="32" tileheight="32" tilecount="264" columns="24">
        <image source="Complete_GUI_Essential_Pack_Free_Version/01_Basic_Collection/01_Flat_Theme/Spritesheets/Spritesheet_UI_Flat.png" width="768" height="352" />
    </tileset>
