package com.example.aja

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
