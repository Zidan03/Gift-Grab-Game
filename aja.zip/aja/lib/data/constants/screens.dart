enum Screens { main, gameOver, login, leaderboard, level }
